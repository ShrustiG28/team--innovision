# 🎨 UI/UX Guide - Decentralized Identity Vault

## Visual Layout

```
┌─────────────────────────────────────────────────────────────────────────────┐
│  🔐 Decentralized Identity Vault                                            │
│  Self-Sovereign Identity using DIDs, Verifiable Credentials & IPFS         │
└─────────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────────┐
│  🆔 Identity      │  📜 Credential      │  🔍 Verify                        │
│  ─────────────────┼────────────────────┼─────────────────                   │
│                  │                    │                                     │
└─────────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────────┐
│                          MAIN CONTENT AREA                                  │
│                      (Content changes by tab)                               │
│                                                                              │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────────┐
│  Footer with links and documentation                                        │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## 🆔 Identity Tab Layout

```
┌─────────────────────────────────────────────────────────────────────────────┐
│  🆔 Your Digital Identity                                                   │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  ┌─────────────────────────────────────────────────────────────────┐       │
│  │ Your DID                                                         │       │
│  │ did:ethr:0x742d35Cc6634C0532925a3b844Bc9e7595f1234            │       │
│  │                                                                  │       │
│  │ [📋 Copy to Clipboard]                                          │       │
│  └─────────────────────────────────────────────────────────────────┘       │
│                                                                              │
│  ┌─────────────────────────────────────────────────────────────────┐       │
│  │ Ethereum Address                                                │       │
│  │ 0x742d35cc6634c0532925a3b844bc9e7595f1234                     │       │
│  └─────────────────────────────────────────────────────────────────┘       │
│                                                                              │
│  ┌─────────────────────────────────────────────────────────────────┐       │
│  │ Public Key (Use for verification)                              │       │
│  │ 0x04a1b2c3d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8a9b0c1d2e3f4a5b6c7...        │
│  │                                                                  │       │
│  │ [📋 Copy Public Key]                                            │       │
│  └─────────────────────────────────────────────────────────────────┘       │
│                                                                              │
│  ┌─────────────────────────────────────────────────────────────────┐       │
│  │ ⚠️ Private Key (Keep Secret!)                                   │       │
│  │ <click to reveal>                                               │       │
│  │ • • • • • • • • • • • • • • • • • • • • • • • • • • • • •      │       │
│  │ Never share this with anyone                                    │       │
│  └─────────────────────────────────────────────────────────────────┘       │
│                                                                              │
│  Created: 11/13/2025, 2:30:45 PM                                          │
│                                                                              │
│  ┌─────────────────────────────────────┬─────────────────────────┐        │
│  │ [🔄 Create New Identity]            │ [🗑️ Clear]            │        │
│  └─────────────────────────────────────┴─────────────────────────┘        │
│                                                                              │
├─────────────────────────────────────────────────────────────────────────────┤
│ ℹ️ What is a DID?                                                           │
│ A DID (Decentralized Identifier) is a globally unique identifier that you  │
│ control. It uses the did:ethr method based on Ethereum. Your DID is       │
│ derived from your public key and can be used to prove ownership of         │
│ credentials without relying on a central authority.                        │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## 📜 Credential Tab Layout

### State 1: No Credentials

```
┌─────────────────────────────────────────────────────────────────────────────┐
│  Current Issuer: Example Tech University                                    │
│  DID: did:ethr:0x0987654321...                                              │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  ┌─────────────────────────────────────────────────────────────────┐       │
│  │ [➕ Request New Credential] ════════════════════════════════════│       │
│  └─────────────────────────────────────────────────────────────────┘       │
│                                                                              │
├─────────────────────────────────────────────────────────────────────────────┤
│ ℹ️ What Happens Here?                                                       │
│ • Step 1: You request a credential from the issuer (University)            │
│ • Step 2: Issuer signs the credential with their private key              │
│ • Step 3: Your browser encrypts it using your private key (AES)           │
│ • Step 4: Encrypted credential is stored on IPFS                          │
│ • Step 5: You get a CID (hash) to retrieve it anytime                     │
└─────────────────────────────────────────────────────────────────────────────┘
```

### State 2: Form Open

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                              │
│  ┌─────────────────────────────────────────────────────────────────┐       │
│  │ 📋 Degree Information                                           │       │
│  │                                                                  │       │
│  │ Degree Type                                                      │       │
│  │ [BachelorDegree        ▼]                                        │       │
│  │                                                                  │       │
│  │ Degree Name                                                      │       │
│  │ [Bachelor of Technology in Computer Science       ]            │       │
│  │                                                                  │       │
│  │ University/Institution                                           │       │
│  │ [Example Tech University              ]                        │       │
│  │                                                                  │       │
│  │ Graduation Year                                                  │       │
│  │ [2025     ]                                                      │       │
│  │                                                                  │       │
│  │ ┌──────────────────────┬──────────────────────┐               │       │
│  │ │ [✓ Request & Store]  │ [✕ Cancel]         │               │       │
│  │ └──────────────────────┴──────────────────────┘               │       │
│  └─────────────────────────────────────────────────────────────────┘       │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

### State 3: Credentials Listed

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                              │
│  📂 My Credentials (2)                                                      │
│                                                                              │
│  ┌─────────────────────────────────────────────────────────────────┐       │
│  │ 1. Bachelor of Technology in Computer Science                   │       │
│  │    University: Example Tech University                          │       │
│  │    Graduation: 2025                                             │       │
│  │    Issued: 11/13/2025                                           │       │
│  │                                                                  │       │
│  │    CID (IPFS Hash)                                              │       │
│  │    QmVpBjxYLg2KzeFjUQPjmZaGV4fXpnZx1XMZgKq1V9qk             │       │
│  │                                                                  │       │
│  │    [📋 Copy CID]  [🔗 Share]                                    │       │
│  └─────────────────────────────────────────────────────────────────┘       │
│                                                                              │
│  ┌─────────────────────────────────────────────────────────────────┐       │
│  │ 2. Master of Science in Computer Science                        │       │
│  │    University: Example Tech University                          │       │
│  │    Graduation: 2026                                             │       │
│  │    Issued: 11/13/2025                                           │       │
│  │                                                                  │       │
│  │    CID (IPFS Hash)                                              │       │
│  │    QmXxXxXxXxXxXxXxXxXxXxXxXxXxXxXxXxXxXxXxXxXx             │       │
│  │                                                                  │       │
│  │    [📋 Copy CID]  [🔗 Share]                                    │       │
│  └─────────────────────────────────────────────────────────────────┘       │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## 🔍 Verify Tab Layout

### State 1: Input

```
┌─────────────────────────────────────────────────────────────────────────────┐
│  🔍 Verify Credential                                                       │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  Credential CID (IPFS Hash)                                                 │
│  ┌──────────────────────────────────────────────────────────────┐          │
│  │ Paste CID here (e.g., Qm...)                                 │          │
│  │                                                              │          │
│  └──────────────────────────────────────────────────────────────┘          │
│                                                                              │
│  You can paste a CID from a credential you received or from your            │
│  stored credentials                                                          │
│                                                                              │
│  ┌──────────────────────────────────────────────────────────────┐          │
│  │ [✓ Verify Credential]                                        │          │
│  └──────────────────────────────────────────────────────────────┘          │
│                                                                              │
├─────────────────────────────────────────────────────────────────────────────┤
│ ℹ️ How Verification Works                                                   │
│ • Step 1: Provide the CID (IPFS hash) of a credential                      │
│ • Step 2: System retrieves the encrypted credential from IPFS              │
│ • Step 3: Your private key decrypts it (stays on your device)             │
│ • Step 4: Backend verifies the issuer's signature                          │
│ • Step 5: Result shows if credential is authentic and unmodified          │
└─────────────────────────────────────────────────────────────────────────────┘
```

### State 2: Valid Credential

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                              │
│  ✅ Credential Valid                                                        │
│  Credential is valid and has not been tampered with                        │
│                                                                              │
│  ┌──────────────────────────────────────────────────────────────┐          │
│  │ Issuer                                                       │          │
│  │ did:ethr:0x0987654321098765432109876543210987654321        │          │
│  └──────────────────────────────────────────────────────────────┘          │
│                                                                              │
│  ┌──────────────────────────────────────────────────────────────┐          │
│  │ Credential Subject (Holder)                                 │          │
│  │ did:ethr:0x742d35Cc6634C0532925a3b844Bc9e7595f1234        │          │
│  └──────────────────────────────────────────────────────────────┘          │
│                                                                              │
│  ┌──────────────────────────────────────────────────────────────┐          │
│  │ Degree Information                                           │          │
│  │                                                              │          │
│  │ Type: BachelorDegree                                        │          │
│  │ Name: Bachelor of Technology in Computer Science           │          │
│  │ University: Example Tech University                         │          │
│  │ Graduation Year: 2025                                       │          │
│  └──────────────────────────────────────────────────────────────┘          │
│                                                                              │
│  ┌──────────────────────────────────────────────────────────────┐          │
│  │ Issuance Date                                               │          │
│  │ 11/13/2025, 2:30:45 PM                                      │          │
│  └──────────────────────────────────────────────────────────────┘          │
│                                                                              │
│  ┌──────────────────────────────────────────────────────────────┐          │
│  │ Credential Types                                            │          │
│  │ VerifiableCredential, DegreeCredential                      │          │
│  └──────────────────────────────────────────────────────────────┘          │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

### State 3: Invalid Credential

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                              │
│  ❌ Credential Invalid                                                       │
│  Credential signature is invalid or has been tampered with                 │
│                                                                              │
│  (Shows same credential details but with error styling)                    │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## Color Scheme

### Primary Colors
- **Blue** (`#3b82f6`) - Primary actions, headers
- **Green** (`#22c55e`) - Success states, credentials
- **Red** (`#ef4444`) - Errors, warnings
- **Purple** (`#a855f7`) - Secondary actions
- **Gray** (`#6b7280`) - Text, borders

### Status Colors
- **Green** - ✅ Valid, Success
- **Red** - ❌ Invalid, Error
- **Yellow** - ⚠️ Warning, Simulated
- **Blue** - ℹ️ Information

### Component Colors
- **Card background** - White (#ffffff)
- **Tab active** - Blue (#3b82f6)
- **Tab inactive** - White with border
- **Input fields** - White with gray border
- **Buttons** - Colored based on action

---

## Typography

### Headings
- **H1** (Page title) - 2xl, bold, blue
- **H2** (Section title) - xl, bold, gray-800
- **H3** (Subsection) - lg, bold, gray-700

### Body Text
- **Regular** - base, gray-700
- **Small** - sm, gray-600
- **Extra small** - xs, gray-500

### Special
- **Monospace** (DIDs, keys) - `font-mono`, text-sm
- **Labels** - sm, semibold, gray-700
- **Helper text** - xs, gray-500

---

## Responsive Design

### Mobile (< 768px)
- Single column layout
- Full-width cards
- Stacked buttons
- Reduced padding

### Tablet (768px - 1024px)
- Two column layout (where applicable)
- Side-by-side buttons
- Standard padding

### Desktop (> 1024px)
- Full layout
- Maximum width: 1280px
- All features visible
- Hover effects

---

## Interactions & States

### Buttons
- **Hover** - Darker shade
- **Active** - Highlighted with shadow
- **Disabled** - Gray, no pointer
- **Loading** - Spinner icon

### Inputs
- **Focus** - Blue ring, blue border
- **Hover** - Light gray background
- **Error** - Red border, red text
- **Disabled** - Gray background, no interaction

### Cards
- **Hover** - Subtle shadow increase
- **Active** - Border highlight
- **Loading** - Opacity reduced

---

## Loading States

### In Progress
```
⏳ Creating DID...
📤 Requesting credential from issuer...
🔐 Encrypting credential locally...
📥 Retrieving credential from IPFS...
```

### Success
```
✅ Credential issued and stored!
✓ VC encrypted
✓ Credential uploaded to IPFS
```

### Error
```
❌ Error: Missing holderDID
❌ Error creating DID: Connection refused
❌ Credential not found in IPFS
```

---

## Accessibility Features

- ✅ Semantic HTML
- ✅ ARIA labels on buttons
- ✅ Keyboard navigation (Tab, Enter)
- ✅ Focus indicators (blue ring)
- ✅ High contrast text
- ✅ Clear error messages
- ✅ Descriptive button text

---

## Browser Support

- ✅ Chrome 120+
- ✅ Firefox 121+
- ✅ Safari 17+
- ✅ Edge 120+

---

## Performance Optimizations

- ✅ Lazy component loading
- ✅ LocalStorage caching
- ✅ Async operations
- ✅ No unnecessary re-renders
- ✅ Optimized images/icons
- ✅ Minified CSS/JS

---

**A clean, intuitive UI focused on clarity and ease of use for demonstrating SSI concepts.**
