# 🔐 Decentralized Identity & Credential Vault

A hackathon-ready prototype demonstrating **Self-Sovereign Identity (SSI)** using DIDs, Verifiable Credentials, and IPFS for decentralized storage.

## 🎯 Project Overview

This full-stack application showcases the complete lifecycle of decentralized identity:

1. **Identity Creation** → Users generate DIDs (Decentralized Identifiers) with public/private key pairs
2. **Credential Issuance** → Issuers create and cryptographically sign Verifiable Credentials (VCs)
3. **Encrypted Storage** → Users encrypt and upload credentials to IPFS (decentralized storage)
4. **Verification** → Anyone can verify credential authenticity and integrity

## 🧩 Technology Stack

### Backend (Node.js + Express)
- **Node.js** - Runtime environment
- **Express** - Web server framework
- **ethers.js** - DID creation and cryptographic signing
- **IPFS HTTP Client** - Decentralized storage integration
- **crypto-js** - AES encryption support

### Frontend (React + Tailwind)
- **React 18** - UI framework
- **Vite** - Build tool
- **Tailwind CSS** - Styling
- **Axios** - HTTP client
- **crypto-js** - Client-side encryption

## 📋 Features

### 🆔 Identity Tab
- Generate unique DID (did:ethr format)
- Display public key and address
- Securely store private key in localStorage (simulated wallet)
- Copy keys to clipboard
- Clear identity for testing

### 📜 Credential Tab
- Request Verifiable Credential from issuer
- Customize degree information (type, name, university, year)
- Encrypt credentials locally using AES
- Upload encrypted credentials to IPFS
- Display CID (IPFS hash) for retrieval
- Share credentials with others

### 🔍 Verify Tab
- Retrieve encrypted credentials from IPFS using CID
- Decrypt locally with private key
- Verify issuer's cryptographic signature
- Display full credential details
- Show verification result (✅ valid or ❌ invalid)

## 🚀 Quick Start

### Prerequisites
- Node.js 16+ and npm
- (Optional) IPFS daemon running locally for persistent storage

### Installation

#### 1. Clone or Download the Project
```bash
cd decentralized-identity-vault
```

#### 2. Setup Backend

```bash
cd backend
npm install
```

**Start Backend Server:**
```bash
npm start
```

Output:
```
================================================================================
🚀 DECENTRALIZED IDENTITY VAULT - BACKEND SERVER
================================================================================
✓ Server running on http://localhost:5000
✓ CORS enabled for frontend integration
================================================================================

🏢 ISSUER (University) Configuration:
   DID: did:ethr:0x1234567890123456789012345678901234567890
   Public Key: 0x1234567890...
```

#### 3. Setup Frontend

In a new terminal:
```bash
cd frontend
npm install
```

**Start Frontend Development Server:**
```bash
npm run dev
```

Browser will open to `http://localhost:3000`

## 💡 Usage Workflow

### Step 1: Create Your Identity
1. Go to **🆔 Identity Tab**
2. Click **"➕ Create New DID"**
3. Your identity is generated and stored in browser's localStorage
4. Copy your DID and public key for reference

**Example Output:**
```
DID: did:ethr:0x742d35Cc6634C0532925a3b844Bc9e7595f1234
Address: 0x742d35cc6634c0532925a3b844bc9e7595f1234
Public Key: 0x04a1b2c3d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8a9b0c1d2e3f4a5b6c7d8e9f0a1b2c3d4e5f6a7b8c9
```

### Step 2: Request a Credential
1. Go to **📜 Credential Tab**
2. Customize degree information (optional)
3. Click **"➕ Request New Credential"**
4. System will:
   - Request VC from issuer (backend)
   - Issuer signs with their private key
   - Frontend encrypts locally
   - Upload to IPFS
5. View your credential with CID

**Example Output:**
```
Credential: Bachelor of Technology in Computer Science
University: Example Tech University
Graduation Year: 2025
CID: QmXxXxXxXxXxXxXxXxXxXxXxXxXxXxXxXxXxXxXxXxXx
```

### Step 3: Verify a Credential
1. Go to **🔍 Verify Tab**
2. Paste the CID from your credentials
3. Click **"✓ Verify Credential"**
4. System will:
   - Retrieve encrypted VC from IPFS
   - Decrypt using your private key
   - Verify issuer's signature
   - Display result

**Example Output:**
```
✅ Credential Valid
Credential is valid and has not been tampered with

Issuer: did:ethr:0x0987654321098765432109876543210987654321
Credential Subject: did:ethr:0x742d35Cc6634C0532925a3b844Bc9e7595f1234
```

## 🔑 API Endpoints

### `POST /api/create-did`
Creates a new DID with key pair
- **Response:**
  ```json
  {
    "success": true,
    "did": "did:ethr:0x...",
    "publicKey": "0x...",
    "privateKey": "0x...",
    "address": "0x..."
  }
  ```

### `POST /api/issue-vc`
Issues a signed Verifiable Credential
- **Request:**
  ```json
  {
    "holderDID": "did:ethr:0x...",
    "holderPublicKey": "0x...",
    "degree": { ... }
  }
  ```
- **Response:**
  ```json
  {
    "success": true,
    "vc": { ... },
    "signature": "0x...",
    "signedVC": "..."
  }
  ```

### `POST /api/verify-vc`
Verifies a VC signature
- **Request:**
  ```json
  {
    "credentialPayload": { ... },
    "signature": "0x..."
  }
  ```
- **Response:**
  ```json
  {
    "success": true,
    "isValid": true,
    "verified": true,
    "message": "✅ Credential is valid..."
  }
  ```

### `POST /api/upload-to-ipfs`
Uploads encrypted credential to IPFS
- **Response:**
  ```json
  {
    "success": true,
    "cid": "QmXxXx...",
    "ipfsGatewayUrl": "https://ipfs.io/ipfs/QmXxXx..."
  }
  ```

### `POST /api/retrieve-from-ipfs`
Retrieves encrypted credential from IPFS
- **Request:** `{ "cid": "QmXxXx..." }`
- **Response:**
  ```json
  {
    "success": true,
    "cid": "QmXxXx...",
    "data": "encrypted_data..."
  }
  ```

## 📊 Data Flow Diagram

```
User Browser                           Backend Server                    IPFS Network
    │                                      │                               │
    ├─ Create DID ─────────────────────> Generate Keys & DID              │
    │  (Identity Tab)                     │                               │
    │  ← DID + Keys ◄─────────────────────┤                               │
    │                                      │                               │
    ├─ Request VC ──────────────────────> Create & Sign VC                │
    │  (Credential Tab)                    │                               │
    │  ← Signed VC ◄─────────────────────┤                               │
    │                                      │                               │
    ├─ Encrypt Locally                    │                               │
    │  (AES with private key)             │                               │
    │                                      │                               │
    ├─ Upload to IPFS ─────────────────────────────────────────────────> Store
    │                                      │                               │
    │  ← CID ◄─────────────────────────────────────────────────────────┤
    │                                      │                               │
    └─ Verify (Verify Tab)               │                               │
       ├─ Retrieve from IPFS ───────────────────────────────────────────> Fetch
       │                                  │                               │
       │  ← Encrypted VC ◄───────────────────────────────────────────────┤
       │                                  │                               │
       ├─ Decrypt Locally               │                               │
       │                                  │                               │
       └─ Verify Signature ────────────> Check Signature                │
          ← Valid/Invalid ◄─────────────┤                               │
```

## 🔐 Security Model

### Private Key Management
- Private keys stored in browser's localStorage (simulated wallet)
- Never sent to backend or IPFS
- Used only for local encryption/decryption

### Credential Encryption
- **Algorithm:** AES encryption
- **Key:** Derived from user's private key
- **Location:** Happens entirely on client-side
- **Result:** Encrypted data uploaded to IPFS

### Signature Verification
- **Algorithm:** ECDSA (Elliptic Curve Digital Signature)
- **Process:**
  1. Hash the credential payload
  2. Sign with issuer's private key
  3. Store signature with credential
  4. Verify by recovering signer's address
  5. Compare with known issuer address

## 📝 Example: Complete Flow

### Create Identity
```javascript
// User clicks "Create New DID"
POST /api/create-did
Response: {
  "did": "did:ethr:0x742d35Cc6634C0532925a3b844Bc9e7595f1234",
  "address": "0x742d35cc6634c0532925a3b844bc9e7595f1234",
  "publicKey": "0x04a1b2c3d4e5f...",
  "privateKey": "0x1234567890ab..."
}
```

### Issue VC
```javascript
// User requests credential
POST /api/issue-vc
Body: {
  "holderDID": "did:ethr:0x742d35...",
  "holderPublicKey": "0x04a1b2...",
  "degree": {
    "type": "BachelorDegree",
    "name": "Bachelor of Technology in Computer Science",
    "university": "Example Tech University",
    "graduationYear": 2025
  }
}

Response: {
  "vc": {
    "@context": ["https://www.w3.org/2018/credentials/v1"],
    "type": ["VerifiableCredential", "DegreeCredential"],
    "issuer": "did:ethr:0x0987...",
    "credentialSubject": {
      "id": "did:ethr:0x742d35...",
      "degree": { ... }
    },
    "issuanceDate": "2025-11-13T..."
  },
  "signature": "0xabcd1234..."
}
```

### Encrypt & Upload to IPFS
```javascript
// Frontend encrypts with private key
const encryptionKey = "0x1234567890ab"; // First 32 chars of private key
const encrypted = AES.encrypt(JSON.stringify(vc), encryptionKey);

// Upload to IPFS
POST /api/upload-to-ipfs
Body: {
  "encryptedVC": "U2FsdGVkX1...",
  "metadata": { ... }
}

Response: {
  "success": true,
  "cid": "QmXxXxXxXxXxXxXxXxXxXxXxXxXxXxXxXxXxXxXxXxXx",
  "ipfsGatewayUrl": "https://ipfs.io/ipfs/QmXxXx..."
}
```

### Verify Credential
```javascript
// User retrieves and verifies
POST /api/retrieve-from-ipfs
Body: { "cid": "QmXxXx..." }
Response: { "data": "U2FsdGVkX1..." }

// Frontend decrypts
const decrypted = AES.decrypt(data, encryptionKey);
const vc = JSON.parse(decrypted);

// Backend verifies signature
POST /api/verify-vc
Body: {
  "credentialPayload": vc,
  "signature": "0xabcd1234..."
}

Response: {
  "isValid": true,
  "verified": true,
  "message": "✅ Credential is valid and has not been tampered with"
}
```

## 🧪 Testing & Debugging

### Use Browser DevTools
1. Open **F12** (Developer Tools)
2. **Application Tab** → **localStorage** to see saved identity
3. **Console Tab** to view detailed logs from frontend
4. **Network Tab** to see API calls

### Check Backend Logs
Backend outputs detailed logs for each operation:
```
📝 Creating new DID for user...
   ✓ DID Created: did:ethr:0x...
   ✓ Public Key: 0x...

📜 Issuing Verifiable Credential...
   Holder DID: did:ethr:0x...
   ✓ VC Payload created
   ✓ VC Signed with issuer private key
   ✓ Signature: 0xabc...
```

### Test Scenarios

**Scenario 1: Valid Credential**
1. Create identity
2. Request credential
3. Verify with correct CID
- **Expected:** ✅ Valid

**Scenario 2: Invalid Signature**
1. Create identity
2. Request credential
3. Modify the CID slightly
4. Try to verify
- **Expected:** ❌ Invalid (data corrupted)

**Scenario 3: Encryption/Decryption**
1. Create identity
2. Request credential
3. Check localStorage to see encrypted data
- **Expected:** Encrypted data is unreadable (AES encrypted)

## 🌍 Using Real IPFS

### Option 1: Run Local IPFS Daemon

**Install IPFS:**
```bash
# On Windows (using Chocolatey)
choco install ipfs

# Or download from https://dist.ipfs.io/
```

**Start IPFS Daemon:**
```bash
ipfs daemon
```

**Expected Output:**
```
Initializing daemon...
go-ipfs version: 0.20.0
System error: listen tcp 127.0.0.1:4001: bind: An attempt was made to use a port in a way forbidden by access rules.
```

If IPFS daemon is running, credentials will be stored persistently.

### Option 2: Use Public IPFS Gateway

Modify `backend/server.js` IPFS client configuration:
```javascript
ipfs = create({
  host: 'ipfs.io',
  port: 443,
  protocol: 'https'
});
```

## 📚 Learning Resources

- [W3C Verifiable Credentials Data Model](https://www.w3.org/TR/vc-data-model/)
- [DID Specification](https://www.w3.org/TR/did-core/)
- [IPFS Documentation](https://docs.ipfs.io/)
- [ethers.js Documentation](https://docs.ethers.org/)
- [Self-Sovereign Identity](https://www.evernym.com/blog/what-is-self-sovereign-identity/)

## 🎓 Key Concepts Explained

### DIDs (Decentralized Identifiers)
- Unique identifiers you fully control
- Format: `did:ethr:0x<ethereum-address>`
- No central authority needed
- Resolvable and cryptographically verifiable

### VCs (Verifiable Credentials)
- Digital credentials you can prove ownership of
- Follow W3C standard format
- Cryptographically signed by issuer
- Can be verified without issuer involvement

### IPFS (InterPlanetary File System)
- Decentralized file storage system
- Files identified by content hash (CID)
- Data persists as long as someone pins it
- Censorship-resistant

### Self-Sovereign Identity (SSI)
- Users control their own identity
- No central authority stores personal data
- Portable credentials follow you
- Privacy-preserving verification

## 🤝 Contributing

This is a hackathon project. Feel free to extend it with:
- Multiple issuer support
- Revocation mechanisms
- Presentation flows
- Mobile app version
- Real blockchain integration

## ⚖️ License

MIT License - Feel free to use for educational and hackathon purposes

## 📞 Support

For issues or questions:
1. Check browser console for errors
2. Review backend logs
3. Ensure backend and frontend are running
4. Try clearing localStorage and starting fresh

---

**Built with ❤️ for Self-Sovereign Identity** 🔐
