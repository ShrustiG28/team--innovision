import express from 'express';
import cors from 'cors';
import { ethers } from 'ethers';
import CryptoJS from 'crypto-js';
import { v4 as uuidv4 } from 'uuid';
import { create } from 'ipfs-http-client';

// ============================================================================
// DECENTRALIZED IDENTITY VAULT - BACKEND SERVER
// ============================================================================
// This backend implements a Self-Sovereign Identity (SSI) system with:
// - DID (Decentralized Identifier) creation and management
// - VC (Verifiable Credential) issuance and verification
// - IPFS integration for decentralized storage
// - Cryptographic signing and verification
// ============================================================================

const app = express();
const PORT = process.env.PORT || 5000;

// Middleware
app.use(cors());
app.use(express.json());

// ============================================================================
// IPFS CLIENT INITIALIZATION (Local Node)
// ============================================================================
// Configure IPFS client to connect to local IPFS daemon
// Make sure you have IPFS running locally: ipfs daemon
// Or use a public gateway: https://ipfs.io
// ============================================================================

let ipfs;
(async () => {
  try {
    // Try to connect to local IPFS daemon first
    ipfs = create({
      host: 'localhost',
      port: 5001,
      protocol: 'http',
      timeout: 5000
    });
    console.log('✓ Connected to local IPFS daemon');
  } catch (error) {
    console.warn('⚠ Local IPFS not available, using fallback (credentials won\'t persist to IPFS)');
    ipfs = null;
  }
})();

// ============================================================================
// SIMULATED ISSUER DATA (In Production: Use Veramo)
// ============================================================================
// For this hackathon prototype, we simulate an issuer (e.g., University)
// with a pre-generated DID and private key
// ============================================================================

// Generate issuer keys once on startup
const issuerWallet = ethers.Wallet.createRandom();
const issuerPublicKey = issuerWallet.publicKey;
const issuerPrivateKey = issuerWallet.privateKey;
const issuerDID = `did:ethr:0x${issuerPublicKey.slice(2).slice(-40).toLowerCase()}`;

console.log('\n🏢 ISSUER (University) Configuration:');
console.log(`   DID: ${issuerDID}`);
console.log(`   Public Key: ${issuerPublicKey}`);

// ============================================================================
// ROUTE: /api/create-did
// ============================================================================
// Creates a new DID for a user with an associated key pair
// Returns: { did, publicKey, privateKey }
// ============================================================================

app.post('/api/create-did', (req, res) => {
  try {
    console.log('\n📝 Creating new DID for user...');

    // Step 1: Generate a random wallet (similar to MetaMask wallet generation)
    const userWallet = ethers.Wallet.createRandom();

    // Step 2: Extract public and private keys
    const userPublicKey = userWallet.publicKey;
    const userPrivateKey = userWallet.privateKey;

    // Step 3: Create a DID using the did:ethr method
    // Format: did:ethr:0x<last 40 characters of public key (Ethereum address)>
    const userAddress = userWallet.address; // This is the Ethereum address
    const userDID = `did:ethr:0x${userAddress.slice(2).toLowerCase()}`;

    console.log(`   ✓ DID Created: ${userDID}`);
    console.log(`   ✓ Public Key: ${userPublicKey.slice(0, 20)}...`);

    // Return the DID and keys to the frontend
    res.json({
      success: true,
      did: userDID,
      publicKey: userPublicKey,
      privateKey: userPrivateKey,
      address: userAddress,
      message: 'DID created successfully. Store the private key securely!'
    });
  } catch (error) {
    console.error('❌ Error creating DID:', error);
    res.status(500).json({ success: false, error: error.message });
  }
});

// ============================================================================
// ROUTE: /api/issue-vc
// ============================================================================
// Issues a Verifiable Credential (VC) to a user
// Accepts: { holderDID, holderPublicKey, degreeData (optional) }
// Returns: Signed VC in W3C format as JWT
// ============================================================================

app.post('/api/issue-vc', async (req, res) => {
  try {
    const { holderDID, holderPublicKey, degree = {} } = req.body;

    if (!holderDID || !holderPublicKey) {
      return res.status(400).json({
        success: false,
        error: 'Missing holderDID or holderPublicKey'
      });
    }

    console.log('\n📜 Issuing Verifiable Credential...');
    console.log(`   Holder DID: ${holderDID}`);

    // Step 1: Create VC payload following W3C Verifiable Credentials format
    const credentialPayload = {
      '@context': ['https://www.w3.org/2018/credentials/v1'],
      type: ['VerifiableCredential', 'DegreeCredential'],
      issuer: issuerDID,
      issuanceDate: new Date().toISOString(),
      credentialSubject: {
        id: holderDID,
        degree: {
          type: degree.type || 'BachelorDegree',
          name: degree.name || 'Bachelor of Technology in Computer Science',
          university: degree.university || 'Example Tech University',
          graduationYear: degree.graduationYear || 2025
        }
      }
    };

    console.log(`   ✓ VC Payload created`);

    // Step 2: Sign the VC payload with issuer's private key
    // Create a hash of the payload and sign it
    const payloadString = JSON.stringify(credentialPayload);
    const payloadHash = ethers.id(payloadString); // Create hash of payload

    // Sign the hash with issuer's private key
    const signature = ethers.SigningKey.from(issuerPrivateKey).sign(payloadHash);
    const compactSignature = signature.compact();

    console.log(`   ✓ VC Signed with issuer private key`);
    console.log(`   ✓ Signature: ${compactSignature.slice(0, 20)}...`);

    // Step 3: Create JWT token (issuer.payload.signature format)
    // Note: This is a simplified JWT - in production use proper JWT library
    const jwt = `${Buffer.from(JSON.stringify({ alg: 'ECDSA', typ: 'JWT' })).toString('base64')}.${Buffer.from(payloadString).toString('base64')}.${compactSignature}`;

    // Step 4: Return the signed VC
    res.json({
      success: true,
      vc: credentialPayload,
      signedVC: jwt,
      signature: compactSignature,
      message: 'Verifiable Credential issued successfully!'
    });
  } catch (error) {
    console.error('❌ Error issuing VC:', error);
    res.status(500).json({ success: false, error: error.message });
  }
});

// ============================================================================
// ROUTE: /api/verify-vc
// ============================================================================
// Verifies a Verifiable Credential by checking the signature
// Accepts: { credentialPayload, signature, issuerPublicKey }
// Returns: { isValid, verified }
// ============================================================================

app.post('/api/verify-vc', (req, res) => {
  try {
    const { credentialPayload, signature } = req.body;

    if (!credentialPayload || !signature) {
      return res.status(400).json({
        success: false,
        error: 'Missing credentialPayload or signature'
      });
    }

    console.log('\n🔍 Verifying Verifiable Credential...');

    // Step 1: Recreate the hash from the payload
    const payloadString = JSON.stringify(credentialPayload);
    const payloadHash = ethers.id(payloadString);

    // Step 2: Recover the signer's address from the signature
    // If the recovered address matches the issuer's address, signature is valid
    try {
      const recoveredAddress = ethers.recoverAddress(payloadHash, signature);
      const issuerAddress = issuerWallet.address;

      const isValid = recoveredAddress.toLowerCase() === issuerAddress.toLowerCase();

      if (isValid) {
        console.log(`   ✓ Signature valid! Issued by: ${recoveredAddress}`);
        console.log(`   ✓ Credential data integrity verified`);
        res.json({
          success: true,
          isValid: true,
          verified: true,
          message: '✅ Credential is valid and has not been tampered with',
          issuer: credentialPayload.issuer,
          subject: credentialPayload.credentialSubject.id
        });
      } else {
        console.log(`   ❌ Signature mismatch!`);
        console.log(`   Expected: ${issuerAddress}`);
        console.log(`   Recovered: ${recoveredAddress}`);
        res.json({
          success: true,
          isValid: false,
          verified: false,
          message: '❌ Credential signature is invalid or has been tampered with'
        });
      }
    } catch (signatureError) {
      console.log(`   ❌ Invalid signature format`);
      res.json({
        success: true,
        isValid: false,
        verified: false,
        message: '❌ Invalid signature format'
      });
    }
  } catch (error) {
    console.error('❌ Error verifying VC:', error);
    res.status(500).json({ success: false, error: error.message });
  }
});

// ============================================================================
// ROUTE: /api/upload-to-ipfs
// ============================================================================
// Uploads encrypted VC to IPFS (if available)
// Accepts: { encryptedVC, metadata }
// Returns: { cid, ipfsGatewayUrl }
// ============================================================================

app.post('/api/upload-to-ipfs', async (req, res) => {
  try {
    const { encryptedVC, metadata = {} } = req.body;

    if (!encryptedVC) {
      return res.status(400).json({
        success: false,
        error: 'Missing encryptedVC'
      });
    }

    console.log('\n📤 Uploading encrypted VC to IPFS...');

    if (!ipfs) {
      console.warn('⚠ IPFS not available - simulating storage');
      // Simulate IPFS response if not connected
      const simulatedCID = `Qm${Buffer.from(encryptedVC).toString('base64').substring(0, 44)}`;
      return res.json({
        success: true,
        cid: simulatedCID,
        ipfsGatewayUrl: `https://ipfs.io/ipfs/${simulatedCID}`,
        message: 'Simulated IPFS storage (local daemon not running)',
        isSimulated: true
      });
    }

    // Upload to IPFS
    const result = await ipfs.add(encryptedVC);
    const cid = result.path;

    console.log(`   ✓ Uploaded to IPFS`);
    console.log(`   ✓ CID: ${cid}`);

    res.json({
      success: true,
      cid,
      ipfsGatewayUrl: `https://ipfs.io/ipfs/${cid}`,
      metadata,
      message: 'Credential uploaded to IPFS successfully!'
    });
  } catch (error) {
    console.error('❌ Error uploading to IPFS:', error);
    res.status(500).json({ success: false, error: error.message });
  }
});

// ============================================================================
// ROUTE: /api/retrieve-from-ipfs
// ============================================================================
// Retrieves encrypted VC from IPFS using CID
// Accepts: { cid }
// Returns: { encryptedVC, data }
// ============================================================================

app.post('/api/retrieve-from-ipfs', async (req, res) => {
  try {
    const { cid } = req.body;

    if (!cid) {
      return res.status(400).json({
        success: false,
        error: 'Missing CID'
      });
    }

    console.log(`\n📥 Retrieving credential from IPFS (CID: ${cid})...`);

    if (!ipfs) {
      console.warn('⚠ IPFS not available - cannot retrieve');
      return res.status(500).json({
        success: false,
        error: 'IPFS not connected. Please start local IPFS daemon.'
      });
    }

    // Retrieve from IPFS
    const chunks = [];
    for await (const chunk of ipfs.cat(cid)) {
      chunks.push(chunk);
    }
    const data = Buffer.concat(chunks).toString('utf-8');

    console.log(`   ✓ Retrieved from IPFS`);

    res.json({
      success: true,
      cid,
      data,
      message: 'Credential retrieved from IPFS successfully!'
    });
  } catch (error) {
    console.error('❌ Error retrieving from IPFS:', error);
    res.status(500).json({ success: false, error: error.message });
  }
});

// ============================================================================
// ROUTE: /api/issuer-info
// ============================================================================
// Returns issuer (e.g., University) information
// Used by frontend to know who is issuing the credentials
// ============================================================================

app.get('/api/issuer-info', (req, res) => {
  res.json({
    name: 'Example Tech University',
    did: issuerDID,
    publicKey: issuerPublicKey,
    description: 'Issuer of digital degrees and certificates'
  });
});

// ============================================================================
// HEALTH CHECK ROUTE
// ============================================================================

app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    timestamp: new Date().toISOString(),
    ipfsConnected: ipfs !== null
  });
});

// ============================================================================
// ERROR HANDLING & SERVER START
// ============================================================================

app.use((req, res) => {
  res.status(404).json({ error: 'Route not found' });
});

app.listen(PORT, () => {
  console.log('\n' + '='.repeat(80));
  console.log('🚀 DECENTRALIZED IDENTITY VAULT - BACKEND SERVER');
  console.log('='.repeat(80));
  console.log(`✓ Server running on http://localhost:${PORT}`);
  console.log(`✓ CORS enabled for frontend integration`);
  console.log('='.repeat(80) + '\n');
});

export default app;
