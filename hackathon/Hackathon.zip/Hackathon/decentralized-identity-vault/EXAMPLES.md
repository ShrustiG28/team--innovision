# 📊 Example Data & Testing Guide

## Example Output From Running Application

### Create DID - Example Output

**Frontend Display:**
```
🆔 Your Digital Identity

Your DID
did:ethr:0x742d35cc6634c0532925a3b844bc9e7595f1234

Ethereum Address
0x742d35cc6634c0532925a3b844bc9e7595f1234

Public Key (Use for verification)
0x04a1b2c3d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8a9b0c1d2e3f4a5b6c7d8e9f0a1b2c3d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8a9b0c1d2e3...

⚠️ Private Key (Keep Secret!)
0x1234567890abcdef1234567890abcdef1234567890abcdef1234567890abcd

Created: 11/13/2025, 2:30:45 PM
```

**Backend Console Output:**
```
📝 Creating new DID for user...
   ✓ DID Created: did:ethr:0x742d35cc6634c0532925a3b844bc9e7595f1234
   ✓ Public Key: 0x04a1b2c3d4e5f6a7b8c9d0e1f2a3b4c5d...
```

**Browser Console:**
```
ℹ️ New DID Created:
   DID: did:ethr:0x742d35cc6634c0532925a3b844bc9e7595f1234
   Public Key: 0x04a1b2c3d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8a9...
```

---

### Request VC - Example Output

**Frontend Display:**
```
📜 My Credentials (1)

1. Bachelor of Technology in Computer Science
   University: Example Tech University
   Graduation: 2025
   Issued: 11/13/2025

   CID (IPFS Hash)
   QmVpBjxYLg2KzeFjUQPjmZaGV4fXpnZx1XMZgKq1V9qk
```

**Backend Console Output:**
```
📜 Issuing Verifiable Credential...
   Holder DID: did:ethr:0x742d35cc6634c0532925a3b844bc9e7595f1234
   ✓ VC Payload created
   ✓ VC Signed with issuer private key
   ✓ Signature: 0xabc123def456789...

📤 Uploading encrypted VC to IPFS...
   ✓ Uploaded to IPFS
   ✓ CID: QmVpBjxYLg2KzeFjUQPjmZaGV4fXpnZx1XMZgKq1V9qk
```

**API Response (JSON):**
```json
{
  "success": true,
  "vc": {
    "@context": ["https://www.w3.org/2018/credentials/v1"],
    "type": ["VerifiableCredential", "DegreeCredential"],
    "issuer": "did:ethr:0x0987654321098765432109876543210987654321",
    "credentialSubject": {
      "id": "did:ethr:0x742d35cc6634c0532925a3b844bc9e7595f1234",
      "degree": {
        "type": "BachelorDegree",
        "name": "Bachelor of Technology in Computer Science",
        "university": "Example Tech University",
        "graduationYear": 2025
      }
    },
    "issuanceDate": "2025-11-13T14:30:45.123Z"
  },
  "signature": "0xabc123def456789...",
  "message": "Verifiable Credential issued successfully!"
}
```

---

### Upload to IPFS - Example Output

**API Response:**
```json
{
  "success": true,
  "cid": "QmVpBjxYLg2KzeFjUQPjmZaGV4fXpnZx1XMZgKq1V9qk",
  "ipfsGatewayUrl": "https://ipfs.io/ipfs/QmVpBjxYLg2KzeFjUQPjmZaGV4fXpnZx1XMZgKq1V9qk",
  "metadata": {
    "holderDID": "did:ethr:0x742d35cc6634c0532925a3b844bc9e7595f1234",
    "issuerDID": "did:ethr:0x0987654321098765432109876543210987654321",
    "issuanceDate": "2025-11-13T14:30:45.123Z",
    "credentialType": ["VerifiableCredential", "DegreeCredential"]
  },
  "message": "Credential uploaded to IPFS successfully!"
}
```

---

### Verify Credential - Example Output

**Frontend Display (Success):**
```
✅ Credential Valid
Credential is valid and has not been tampered with

Issuer
did:ethr:0x0987654321098765432109876543210987654321

Credential Subject (Holder)
did:ethr:0x742d35cc6634c0532925a3b844bc9e7595f1234

Degree Information
Type: BachelorDegree
Name: Bachelor of Technology in Computer Science
University: Example Tech University
Graduation Year: 2025

Issuance Date
11/13/2025, 2:30:45 PM

Credential Types
VerifiableCredential, DegreeCredential
```

**Backend Console Output:**
```
🔍 Verifying Verifiable Credential...
   ✓ Signature valid! Issued by: 0x0987654321098765432109876543210987654321
   ✓ Credential data integrity verified
```

**API Response:**
```json
{
  "success": true,
  "isValid": true,
  "verified": true,
  "message": "✅ Credential is valid and has not been tampered with",
  "issuer": "did:ethr:0x0987654321098765432109876543210987654321",
  "subject": "did:ethr:0x742d35cc6634c0532925a3b844bc9e7595f1234"
}
```

---

### Failed Verification - Example Output

**Frontend Display (Failure):**
```
❌ Credential Invalid
Credential signature is invalid or has been tampered with
```

**Backend Console Output:**
```
🔍 Verifying Verifiable Credential...
   ❌ Signature mismatch!
   Expected: 0x0987654321098765432109876543210987654321
   Recovered: 0xWrongAddressWrongAddress...
```

**API Response:**
```json
{
  "success": true,
  "isValid": false,
  "verified": false,
  "message": "❌ Credential signature is invalid or has been tampered with"
}
```

---

## LocalStorage Data Examples

### userIdentity
```json
{
  "did": "did:ethr:0x742d35cc6634c0532925a3b844bc9e7595f1234",
  "publicKey": "0x04a1b2c3d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8a9b0c1d2e3f4a5b6c7d8e9f0a1b2c3d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8a9b0c1d2e3f4a5b6c7d8e9f0a1b2c3d4e5f6a7b8c9",
  "privateKey": "0x1234567890abcdef1234567890abcdef1234567890abcdef1234567890abcd",
  "address": "0x742d35cc6634c0532925a3b844bc9e7595f1234",
  "createdAt": "2025-11-13T14:25:00.000Z"
}
```

### userCredentials
```json
[
  {
    "id": 1699872900000,
    "did": "did:ethr:0x742d35cc6634c0532925a3b844bc9e7595f1234",
    "issuer": "did:ethr:0x0987654321098765432109876543210987654321",
    "cid": "QmVpBjxYLg2KzeFjUQPjmZaGV4fXpnZx1XMZgKq1V9qk",
    "signature": "0xabc123def456789def456789abc123def456789def456789abc123def456789",
    "degreeData": {
      "type": "BachelorDegree",
      "name": "Bachelor of Technology in Computer Science",
      "university": "Example Tech University",
      "graduationYear": 2025
    },
    "issuanceDate": "2025-11-13T14:30:45.123Z",
    "isSimulated": false,
    "ipfsGatewayUrl": "https://ipfs.io/ipfs/QmVpBjxYLg2KzeFjUQPjmZaGV4fXpnZx1XMZgKq1V9qk"
  },
  {
    "id": 1699872950000,
    "did": "did:ethr:0x742d35cc6634c0532925a3b844bc9e7595f1234",
    "issuer": "did:ethr:0x0987654321098765432109876543210987654321",
    "cid": "QmXxXxXxXxXxXxXxXxXxXxXxXxXxXxXxXxXxXxXxXxXx",
    "signature": "0xdef456789abc123abc123def456789abc123def456789abc123def456789ab",
    "degreeData": {
      "type": "MastersDegree",
      "name": "Master of Science in Computer Science",
      "university": "Example Tech University",
      "graduationYear": 2026
    },
    "issuanceDate": "2025-11-13T14:35:50.456Z",
    "isSimulated": false,
    "ipfsGatewayUrl": "https://ipfs.io/ipfs/QmXxXxXxXxXxXxXxXxXxXxXxXxXxXxXxXxXxXxXxXxXx"
  }
]
```

---

## Testing Scenarios & Expected Results

### Test 1: Create Identity
**Steps:**
1. Open http://localhost:3000
2. Go to Identity tab
3. Click "Create New DID"

**Expected Result:**
- ✅ DID generated (did:ethr:0x...)
- ✅ Public key displayed
- ✅ Private key hidden (behind click)
- ✅ Address shown
- ✅ Saved to localStorage

**Verification:**
```javascript
// In browser console
localStorage.getItem('userIdentity')
// Should show JSON with did, publicKey, privateKey
```

---

### Test 2: Request Multiple Credentials
**Steps:**
1. Identity exists (from Test 1)
2. Go to Credential tab
3. Click "Request New Credential"
4. Change degree name
5. Click "Request & Store"
6. Repeat 2-3 times

**Expected Result:**
- ✅ Each credential gets unique CID
- ✅ Multiple credentials listed
- ✅ All saved to localStorage
- ✅ Each shows different date/time

**Verification:**
```javascript
// In browser console
JSON.parse(localStorage.getItem('userCredentials')).length
// Should be 2-3 depending on repetitions
```

---

### Test 3: Verify Valid Credential
**Steps:**
1. From Credential tab, copy a CID
2. Go to Verify tab
3. Paste CID
4. Click "Verify Credential"

**Expected Result:**
- ✅ Messages show: "Retrieving...", "Decrypting...", "Verifying..."
- ✅ Result shows "✅ Credential Valid"
- ✅ Displays issuer, subject, degree details
- ✅ Shows issuance date

**Verification:**
```
✅ Credential Valid
Credential is valid and has not been tampered with
```

---

### Test 4: Tampered Credential Fails
**Steps:**
1. Copy a valid CID
2. Change 1-2 characters in the CID
3. Paste modified CID in Verify tab
4. Click "Verify Credential"

**Expected Result:**
- ✅ Error message: "CID not found" or similar
- ✅ Verification fails gracefully

**Verification:**
```
❌ CID not found in IPFS or local storage
```

---

### Test 5: Encryption/Decryption
**Steps:**
1. Create identity
2. Request credential
3. Open DevTools → Application → localStorage
4. Copy encryptedVC from credential record
5. Manually try to decrypt (should fail without key)

**Expected Result:**
- ✅ Encrypted data looks like: `U2FsdGVkX1...`
- ✅ Cannot read encrypted data directly
- ✅ Only frontend with private key can decrypt

---

### Test 6: Multiple Identities
**Steps:**
1. Create Identity #1
2. Copy DID #1
3. Go to Identity tab
4. Click "Create New Identity"
5. Compare DIDs

**Expected Result:**
- ✅ Identity #2 has different DID
- ✅ Identity #2 has different public key
- ✅ Identity #2 has different private key
- ✅ Identity #1 data overwritten (if not cleared)
- ✅ Click "Clear" to remove

---

### Test 7: API Error Handling
**Steps:**
1. Backend stopped
2. Try to create DID

**Expected Result:**
- ✅ Error message: "Cannot reach backend"
- ✅ No crash, graceful error

**Verification:**
```javascript
// In browser console
// Check error message
```

---

### Test 8: IPFS Fallback
**Steps:**
1. No IPFS daemon running
2. Request credential

**Expected Result:**
- ✅ Shows "Simulated IPFS" message
- ✅ CID still generated
- ✅ System works without real IPFS
- ✅ Verification works with simulated CID

---

## Performance Testing

### Expected Times
```
Create DID:        ~200-300ms
Request VC:        ~400-600ms (signing + encryption)
Upload to IPFS:    ~500-2000ms (depends on daemon)
Verify VC:         ~300-500ms (decryption + verification)
```

### Load Test
**Steps:**
1. Request 10 credentials rapidly
2. Monitor browser memory
3. Check localStorage size

**Expected Result:**
- ✅ All credentials stored
- ✅ No memory leaks
- ✅ localStorage < 1MB

---

## Security Testing

### Test Private Key Exposure
**Step:** Open DevTools, check localStorage
**Expected:** Private key visible but not transmitted
**Risk:** Local compromise
**Mitigation:** Use secure enclave in production

### Test Signature Forgery
**Step:** Modify credential payload, try to verify
**Expected:** Verification fails
**Result:** ✅ Signature verification works

### Test Encryption Key Reuse
**Step:** Multiple credentials from same identity
**Expected:** Each uses same key (derived from private key)
**Security Note:** Acceptable for single user, could improve with KDF

---

## Browser Compatibility

**Tested On:**
- ✅ Chrome 120+
- ✅ Firefox 121+
- ✅ Safari 17+
- ✅ Edge 120+

**Features Used:**
- localStorage (required)
- crypto-js (included)
- Fetch API / axios (required)
- ES6+ features (required)

---

## Common Issues & Solutions

| Issue | Cause | Solution |
|-------|-------|----------|
| "Cannot find module" | Dependencies not installed | `npm install` |
| Port 5000 already in use | Another service using port | `netstat -ano \| findstr :5000` |
| Port 3000 already in use | Another service using port | `netstat -ano \| findstr :3000` |
| CORS error | Backend not running | Start backend: `npm start` |
| localStorage empty | First time using | Create identity first |
| Simulated IPFS | IPFS daemon not running | Start IPFS or use simulated mode |
| Signature verification fails | Wrong private key | Ensure same identity creating & verifying |

---

## Sample cURL Commands

### Create DID
```bash
curl -X POST http://localhost:5000/api/create-did \
  -H "Content-Type: application/json"
```

### Issue VC
```bash
curl -X POST http://localhost:5000/api/issue-vc \
  -H "Content-Type: application/json" \
  -d '{
    "holderDID": "did:ethr:0x...",
    "holderPublicKey": "0x...",
    "degree": {
      "type": "BachelorDegree",
      "name": "Bachelor of Technology in Computer Science",
      "university": "Example Tech University",
      "graduationYear": 2025
    }
  }'
```

### Verify VC
```bash
curl -X POST http://localhost:5000/api/verify-vc \
  -H "Content-Type: application/json" \
  -d '{
    "credentialPayload": { ... },
    "signature": "0x..."
  }'
```

---

**All these examples and tests verify that the system works correctly end-to-end!**
