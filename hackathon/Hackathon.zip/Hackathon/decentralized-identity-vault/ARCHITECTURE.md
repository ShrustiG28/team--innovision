# 🔐 Decentralized Identity Vault - Architecture & Technical Deep Dive

## System Architecture

```
┌─────────────────────────────────────────────────────────────────────┐
│                         FRONTEND (React)                             │
│  ┌──────────────┬──────────────┬──────────────┐                     │
│  │  Identity    │ Credential   │   Verify     │                     │
│  │   Tab        │    Tab       │    Tab       │                     │
│  └──────────────┴──────────────┴──────────────┘                     │
│  ┌──────────────────────────────────────────────┐                   │
│  │   Local Storage (User Identity + CIDs)       │                   │
│  └──────────────────────────────────────────────┘                   │
│  ┌──────────────────────────────────────────────┐                   │
│  │   crypto-js (AES Encryption)                 │                   │
│  └──────────────────────────────────────────────┘                   │
└──────────────────────────────────────────────────────────────────────┘
                              ↑↓
                          HTTP (Axios)
                              ↓↑
┌──────────────────────────────────────────────────────────────────────┐
│                      BACKEND (Node.js + Express)                      │
│  ┌──────────────────────────────────────────────┐                   │
│  │  POST /api/create-did                        │                   │
│  │  POST /api/issue-vc                          │                   │
│  │  POST /api/verify-vc                         │                   │
│  │  POST /api/upload-to-ipfs                    │                   │
│  │  POST /api/retrieve-from-ipfs                │                   │
│  └──────────────────────────────────────────────┘                   │
│  ┌──────────────────────────────────────────────┐                   │
│  │   ethers.js (DID & Signing)                  │                   │
│  └──────────────────────────────────────────────┘                   │
│  ┌──────────────────────────────────────────────┐                   │
│  │   Issuer Wallet (Pre-generated)              │                   │
│  │   DID: did:ethr:0x...                        │                   │
│  └──────────────────────────────────────────────┘                   │
└──────────────────────────────────────────────────────────────────────┘
                              ↑↓
                       HTTP/IPFS Protocol
                              ↓↑
┌──────────────────────────────────────────────────────────────────────┐
│                     IPFS Network                                      │
│  (Decentralized storage for encrypted credentials)                   │
│  Content hash (CID) identifies each credential                        │
└──────────────────────────────────────────────────────────────────────┘
```

## Data Models

### User Identity Model
```javascript
{
  did: "did:ethr:0x742d35Cc6634C0532925a3b844Bc9e7595f1234",
  address: "0x742d35cc6634c0532925a3b844bc9e7595f1234",
  publicKey: "0x04a1b2c3d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8a9...",
  privateKey: "0x1234567890abcdef1234567890abcdef123456...",
  createdAt: "2025-11-13T12:34:56Z"
}
```

### Verifiable Credential (VC) Model
```javascript
{
  "@context": ["https://www.w3.org/2018/credentials/v1"],
  "type": ["VerifiableCredential", "DegreeCredential"],
  "issuer": "did:ethr:0x0987654321098765432109876543210987654321",
  "credentialSubject": {
    "id": "did:ethr:0x742d35Cc6634C0532925a3b844Bc9e7595f1234",
    "degree": {
      "type": "BachelorDegree",
      "name": "Bachelor of Technology in Computer Science",
      "university": "Example Tech University",
      "graduationYear": 2025
    }
  },
  "issuanceDate": "2025-11-13T12:34:56Z"
}
```

### Signature Model
```javascript
{
  algorithm: "ECDSA",
  hash: "0xabc123def456...", // Hash of credential payload
  signature: "0xdef456abc123...", // Signed hash
  signer: "0x0987654321098765432109876543210987654321" // Issuer address
}
```

### Credential Record (Stored Locally)
```javascript
{
  id: 1699876496000,
  did: "did:ethr:0x742d35Cc6634C0532925a3b844Bc9e7595f1234",
  issuer: "did:ethr:0x0987654321098765432109876543210987654321",
  cid: "QmVpBjxYLg2KzeFjUQPjmZaGV4fXpnZx1XMZgKq1V9qk",
  signature: "0xdef456abc123...",
  degreeData: { /* degree info */ },
  issuanceDate: "2025-11-13T12:34:56Z",
  isSimulated: false,
  ipfsGatewayUrl: "https://ipfs.io/ipfs/QmVpBjxYLg2KzeFjUQPjmZaGV4fXpnZx1XMZgKq1V9qk"
}
```

## Cryptographic Flows

### 1. DID Creation Flow

```
Step 1: Generate Random Wallet
  Input: None
  Process: ethers.Wallet.createRandom()
  Output: { address, publicKey, privateKey }

Step 2: Create DID
  Input: publicKey, address
  Process: did:ethr:0x + address.slice(-40)
  Output: did:ethr:0x742d35Cc6634C0532925a3b844Bc9e7595f1234

Step 3: Store Locally
  Input: { did, publicKey, privateKey, address }
  Process: JSON.stringify → localStorage.setItem()
  Output: Persistent identity in browser storage
```

### 2. Credential Issuance & Signing Flow

```
Step 1: Create Credential Payload
  Input: holder DID, degree info
  Process: Build W3C VC structure
  Output: credentialPayload (JSON object)

Step 2: Sign Credential
  Input: credentialPayload, issuer privateKey
  Process:
    a) Hash payload: ethers.id(JSON.stringify(payload))
    b) Sign hash: SigningKey.sign(hash)
    c) Get signature: Signature.compact()
  Output: compactSignature (66-char hex string)

Step 3: Return to Frontend
  Input: credentialPayload, signature
  Output: {vc, signature, signedVC (JWT)}
```

### 3. Encryption & Upload Flow

```
Step 1: Derive Encryption Key
  Input: user privateKey
  Process: key = privateKey.slice(0, 32)
  Output: 32-char hex encryption key

Step 2: Encrypt Credential
  Input: credentialPayload, encryptionKey
  Process: CryptoJS.AES.encrypt(JSON.stringify(vc), key)
  Output: encryptedVC (encrypted + base64 encoded)

Step 3: Upload to IPFS
  Input: encryptedVC
  Process: ipfs.add(encryptedVC)
  Output: { path: "QmXxXx..." } (CID)

Step 4: Store CID Record
  Input: cid, metadata
  Process: localStorage.setItem('userCredentials', ...)
  Output: CID saved for future retrieval
```

### 4. Verification & Decryption Flow

```
Step 1: Retrieve from IPFS
  Input: cid
  Process: ipfs.cat(cid)
  Output: encryptedVC (encrypted string)

Step 2: Decrypt Locally
  Input: encryptedVC, encryptionKey
  Process: CryptoJS.AES.decrypt(encryptedVC, key)
  Output: credentialPayload (original VC)

Step 3: Verify Signature
  Input: credentialPayload, signature
  Process:
    a) Recreate hash: ethers.id(JSON.stringify(payload))
    b) Recover signer: ethers.recoverAddress(hash, signature)
    c) Compare: recoveredAddress === issuerAddress
  Output: isValid (true/false)

Step 4: Display Result
  Input: isValid, credentialPayload
  Process: Format and display verification result
  Output: ✅ Valid or ❌ Invalid
```

## Key Security Considerations

### Private Key Handling
- **Storage Location:** Browser localStorage (persistent but not encrypted)
- **Best Practice:** In production, use secure enclave or hardware wallet
- **Risk:** If device is compromised, private key is exposed
- **Mitigation:** Users should use different identities for different purposes

### Encryption Key Derivation
- **Method:** First 32 characters of private key
- **Security:** Unique per user, derived from private key
- **Risk:** Weak key if private key is compromised
- **Mitigation:** Could use proper KDF (Key Derivation Function) in production

### Signature Verification
- **Method:** ECDSA with recovery
- **Strength:** Mathematically proven secure
- **Limitation:** Only verifies issuer's signature, not revocation status
- **Consideration:** Could implement revocation list in production

### IPFS Storage
- **Security:** Content-addressed, immutable by default
- **Privacy:** Encrypted before upload, data itself unreadable
- **Consideration:** Metadata (metadata object) is not encrypted
- **Risk:** CID alone doesn't reveal data, but metadata timing could

## Performance Optimization

### Frontend
- **Lazy loading:** Components load on tab click
- **LocalStorage caching:** Credentials cached locally
- **Async operations:** Doesn't block UI during API calls

### Backend
- **No database:** In-memory issuer configuration
- **Stateless:** Each request independent
- **CORS enabled:** Efficient cross-origin requests

### IPFS
- **Local daemon:** If running locally, faster retrieval
- **Public gateway:** Falls back if local unavailable
- **Caching:** Browser caches responses

## Error Handling

### Frontend Error Cases
1. **No identity:** User must create identity first
2. **Network error:** "Cannot reach backend" message
3. **Decryption failed:** Wrong private key or corrupted data
4. **IPFS unavailable:** Gracefully falls back to simulated storage

### Backend Error Cases
1. **Invalid payload:** 400 Bad Request
2. **Signing error:** 500 Internal Server Error
3. **IPFS offline:** Graceful fallback to simulation
4. **Missing parameters:** 400 Bad Request with error message

## Testing Strategies

### Unit Tests (Recommended)
```javascript
describe('DID Creation', () => {
  test('should generate valid DID format', () => { ... });
  test('should create unique DIDs', () => { ... });
});

describe('VC Signing', () => {
  test('should sign and verify successfully', () => { ... });
  test('should reject tampered data', () => { ... });
});
```

### Integration Tests
```javascript
describe('Complete Flow', () => {
  test('should create DID → issue VC → verify', () => { ... });
  test('should encrypt → upload → decrypt', () => { ... });
});
```

### Manual Testing Scenarios
1. **Happy path:** All operations succeed
2. **Tampered data:** Modify CID, signature verification fails
3. **Network offline:** Backend unavailable
4. **Multiple identities:** Create different DIDs, ensure isolation
5. **Concurrent requests:** Multiple VCs from same identity

## Deployment Considerations

### Frontend Deployment
- **Platform:** Vercel, Netlify, GitHub Pages
- **Build:** `npm run build` creates `dist/` folder
- **Environment:** Update API_URL in axios calls
- **DNS:** Point domain to deployment

### Backend Deployment
- **Platform:** Heroku, AWS Lambda, Azure App Service
- **Environment Variables:** API_URL, IPFS_URL, PORT
- **Database:** Currently stateless, add DB for persistence
- **Scaling:** Load balance if needed

### IPFS Deployment
- **Option 1:** Use Pinata (pinned IPFS service)
- **Option 2:** Run own IPFS node
- **Option 3:** Use Filecoin for long-term storage

## Future Enhancements

1. **Revocation Mechanism**
   - Issuer can revoke credentials
   - Maintain revocation list
   - Verification checks revocation status

2. **Multiple Issuers**
   - Support various issuer types
   - Issuer registry with DID resolution
   - Trust framework

3. **Presentation Protocol**
   - Users can selectively disclose credentials
   - Verifier requests specific claims
   - Zero-knowledge proofs

4. **Mobile Integration**
   - React Native version
   - QR code for credential sharing
   - Biometric unlocking

5. **Blockchain Integration**
   - Store DID on Ethereum
   - Credential registry on blockchain
   - Smart contract verification

6. **Privacy Enhancements**
   - Selective disclosure
   - Anonymous credentials
   - Zero-knowledge proofs

## References

- [W3C Verifiable Credentials Data Model 1.0](https://www.w3.org/TR/vc-data-model/)
- [Decentralized Identifiers (DIDs) v1.0](https://www.w3.org/TR/did-core/)
- [DID Method Specification: did:ethr](https://github.com/decentralized-identity/ethr-did-resolver/blob/master/doc/did-method-spec.md)
- [IPFS Documentation](https://docs.ipfs.io/)
- [ethers.js Documentation](https://docs.ethers.org/)
- [Self-Sovereign Identity Principles](https://github.com/WebOfTrustInfo/self-sovereign-identity/blob/master/self-sovereign-identity-principles.md)

---

**This architecture demonstrates real-world self-sovereign identity principles with production-ready patterns.**
