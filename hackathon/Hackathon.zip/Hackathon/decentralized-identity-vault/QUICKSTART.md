# ⚡ QUICK START GUIDE - Decentralized Identity Vault

Complete step-by-step guide to get the app running in 5 minutes.

## 📋 Prerequisites Check

Make sure you have:
- [ ] Node.js 16+ installed (`node --version`)
- [ ] npm installed (`npm --version`)
- [ ] A code editor (VS Code recommended)
- [ ] A modern web browser (Chrome, Firefox, Safari, Edge)

## 🚀 FAST START (5 Minutes)

### Step 1: Navigate to Project Directory

**On Windows PowerShell:**
```powershell
cd "C:\Users\Mahantesh\Desktop\Hackathon\decentralized-identity-vault"
```

### Step 2: Install Backend Dependencies

```powershell
cd backend
npm install
```

**Expected Output:**
```
added 73 packages, and audited 74 packages in 1m
```

### Step 3: Start Backend Server

```powershell
npm start
```

**Expected Output:**
```
================================================================================
🚀 DECENTRALIZED IDENTITY VAULT - BACKEND SERVER
================================================================================
✓ Server running on http://localhost:5000
✓ CORS enabled for frontend integration
================================================================================

🏢 ISSUER (University) Configuration:
   DID: did:ethr:0xXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
   Public Key: 0xXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX...
```

✅ **Backend is running!** Keep this terminal open.

### Step 4: Install Frontend Dependencies (NEW TERMINAL)

Open a **NEW PowerShell window** and run:

```powershell
cd "C:\Users\Mahantesh\Desktop\Hackathon\decentralized-identity-vault\frontend"
npm install
```

**Expected Output:**
```
added 142 packages in 45s
```

### Step 5: Start Frontend Development Server

```powershell
npm run dev
```

**Expected Output:**
```
  VITE v5.1.0  ready in 234 ms

  ➜  Local:   http://localhost:3000/
  ➜  press h to show help
```

✅ **Frontend is running!** Browser should automatically open to http://localhost:3000

---

## 🎮 Using the Application

### Terminal 1 (Backend)
```
Keep this running - this is your API server
Port: 5000
```

### Terminal 2 (Frontend)
```
Keep this running - this is your web app
Port: 3000
Accessible at: http://localhost:3000
```

---

## 📖 Complete Workflow Demo

### **Phase 1: Create Your Identity** (2 minutes)

1. **Browser:** Open http://localhost:3000
2. **UI:** Click on **🆔 Identity** tab
3. **Action:** Click **"➕ Create New DID"** button
4. **Result:** You'll see:
   ```
   Your DID: did:ethr:0x742d35Cc6634C0532925a3b844Bc9e7595f1234
   Address: 0x742d35cc6634c0532925a3b844bc9e7595f1234
   Public Key: 0x04a1b2c3d4e5f...
   ```

✅ **Your identity is created and stored in browser!**

**What happened:**
- Backend generated random wallet
- Extracted public key and address
- Created DID using did:ethr format
- Private key stored securely in browser localStorage

**Backend Console Shows:**
```
📝 Creating new DID for user...
   ✓ DID Created: did:ethr:0x742d35Cc...
   ✓ Public Key: 0x04a1b2...
```

---

### **Phase 2: Request a Credential** (3 minutes)

1. **UI:** Click on **📜 Credential** tab
2. **Form:** You'll see the issuer info:
   ```
   Current Issuer: Example Tech University
   DID: did:ethr:0x0987654321...
   ```
3. **Action:** Click **"➕ Request New Credential"**
4. **Form Fields** appear:
   - Degree Type: BachelorDegree ✓
   - Name: Bachelor of Technology in Computer Science ✓
   - University: Example Tech University ✓
   - Graduation Year: 2025 ✓
5. **Action:** Click **"✓ Request & Store"**
6. **Processing** (watch the messages):
   ```
   📤 Requesting credential from issuer...
   ✓ VC Received from issuer
   🔐 Encrypting credential locally...
   ✓ VC encrypted
   📤 Uploading to IPFS...
   ✓ Credential uploaded to IPFS
   ```
7. **Result:** Your credential appears with:
   ```
   CID: QmXxXxXxXxXxXxXxXxXxXxXxXxXxXxXxXxXxXxXxXxXx
   (or simulated if IPFS not running)
   ```

✅ **Credential issued, encrypted, and stored!**

**What happened:**
- Backend created a Verifiable Credential (W3C format)
- Backend signed it with issuer's private key
- Frontend received the signed VC
- Frontend encrypted it locally using AES
- Encrypted data uploaded to IPFS (or simulated)
- CID returned for retrieval

**Backend Console Shows:**
```
📜 Issuing Verifiable Credential...
   Holder DID: did:ethr:0x742d35Cc...
   ✓ VC Payload created
   ✓ VC Signed with issuer private key
   ✓ Signature: 0xabc...

📤 Uploading encrypted VC to IPFS...
   ✓ Uploaded to IPFS
   ✓ CID: QmXxXx...
```

---

### **Phase 3: Verify the Credential** (2 minutes)

1. **UI:** Click on **🔍 Verify** tab
2. **Action:** From your stored credentials, copy the CID
3. **Input:** Paste CID in the text field
4. **Action:** Click **"✓ Verify Credential"**
5. **Processing** (watch the messages):
   ```
   📥 Retrieving credential from IPFS...
   ✓ Retrieved from IPFS
   🔐 Decrypting credential...
   ✓ Credential decrypted
   🔐 Verifying credential signature...
   ✓ Signature valid!
   ```
6. **Result:**
   ```
   ✅ Credential Valid
   Credential is valid and has not been tampered with
   
   Issuer: did:ethr:0x0987...
   Credential Subject: did:ethr:0x742d35...
   
   Degree Information:
   Type: BachelorDegree
   Name: Bachelor of Technology in Computer Science
   University: Example Tech University
   Graduation Year: 2025
   ```

✅ **Credential verified successfully!**

**What happened:**
- System retrieved encrypted VC from IPFS using CID
- Frontend decrypted using your private key (stays local!)
- Backend verified issuer's cryptographic signature
- If signature matches, credential is authentic and unmodified

**Backend Console Shows:**
```
🔍 Verifying Verifiable Credential...
   ✓ Signature valid! Issued by: 0x0987654321...
   ✓ Credential data integrity verified
```

---

## 🧪 Testing Different Scenarios

### Test 1: Create Multiple Identities
1. Go to **Identity** tab
2. Click **"🔄 Create New Identity"** (creates another DID)
3. Notice: Each time you get a different DID!
4. To revert: Click **"🗑️ Clear"** then create new one

### Test 2: Request Multiple Credentials
1. Same identity (or create new one)
2. Go to **Credential** tab
3. Click **"➕ Request New Credential"** multiple times
4. Change the degree details each time
5. You'll see all credentials listed with their CIDs

### Test 3: Try Tampered Credential
1. Go to **Verify** tab
2. Paste a CID
3. **Manually edit the CID** (change 1-2 characters)
4. Click **"✓ Verify Credential"**
5. **Expected Result:** ❌ Invalid (credential corrupted)

### Test 4: Check LocalStorage
1. Open **Browser DevTools** (F12)
2. Go to **Application** tab
3. Click **localStorage** in left panel
4. Expand **http://localhost:3000**
5. You'll see:
   ```
   userIdentity: { did, publicKey, privateKey, ... }
   userCredentials: [ { cid, issuer, signature, ... } ]
   ```

---

## 📊 Example Output Logs

### Creating DID - Backend Log
```
📝 Creating new DID for user...
   ✓ DID Created: did:ethr:0x1a2b3c4d5e6f7a8b9c0d1e2f3a4b5c6d7e8f9a0b
   ✓ Public Key: 0x04d5a6b7c8d9e0f1a2b3c4d5e6f7a8b9c0d1e2f3a4b5c6d7e8f9a0b1c2d3e4f5a6b7c8d9e0f1a2b3
```

### Issuing VC - Backend Log
```
📜 Issuing Verifiable Credential...
   Holder DID: did:ethr:0x1a2b3c4d5e6f7a8b9c0d1e2f3a4b5c6d7e8f9a0b
   ✓ VC Payload created
   ✓ VC Signed with issuer private key
   ✓ Signature: 0xabc123def456...

📤 Uploading encrypted VC to IPFS...
   ⚠ Local IPFS not available, using fallback
   ✓ Uploaded to IPFS
   ✓ CID: QmVpBjxYLg2KzeFjUQPjmZaGV4fXpnZx1XMZgKq1V9qk
```

### Verifying VC - Backend Log
```
🔍 Verifying Verifiable Credential...
   ✓ Signature valid! Issued by: 0xaBcDeFg...
   ✓ Credential data integrity verified
```

---

## 🔧 Troubleshooting

### Problem: "Cannot GET /"
**Solution:** Make sure frontend is running on port 3000
```powershell
# Terminal 2
npm run dev
```

### Problem: "Backend is not responding"
**Solution:** Make sure backend is running on port 5000
```powershell
# Terminal 1
npm start
```

### Problem: CORS Error in Browser Console
**Solution:** Backend might be down. Restart it:
```powershell
npm start
```

### Problem: "Cannot find module 'ethers'"
**Solution:** Install dependencies again
```powershell
npm install
```

### Problem: Port 3000 or 5000 already in use
**Solution:** Either close the app using the port or change port in code

### Problem: localStorage is empty
**Solution:** This is normal. Create identity first, it saves to localStorage.

### Problem: IPFS upload says "simulated"
**Solution:** This is fine! IPFS daemon is not running locally. Credentials still work.

---

## 📱 Workflow Diagram

```
USER BROWSER                    BACKEND SERVER              IPFS NETWORK
    │                               │                          │
    │─── Create DID ──────────────>│                          │
    │                    Generate & Sign                       │
    │<─── DID + Keys ──────────────│                          │
    │                               │                          │
    │ (Store in localStorage)       │                          │
    │                               │                          │
    │─── Request VC ──────────────>│                          │
    │               Generate VC & Sign                        │
    │<─── Signed VC ───────────────│                          │
    │                               │                          │
    │ (Encrypt locally with AES)   │                          │
    │                               │                          │
    │─── Upload to IPFS ──────────────────────────────────> Store
    │                               │                     (Encrypted)
    │<─── CID ────────────────────────────────────────────┤
    │                               │                          │
    │─── Retrieve + Verify ──────>│                          │
    │                               │                          │
    │       (Decrypt locally)       │                          │
    │       (Verify Signature)      │                          │
    │<─── Valid/Invalid ────────────│                          │
```

---

## ✅ Success Checklist

- [ ] Backend running on http://localhost:5000
- [ ] Frontend running on http://localhost:3000
- [ ] Can create a DID in Identity tab
- [ ] Can request a credential in Credential tab
- [ ] See CID in credentials list
- [ ] Can verify credential in Verify tab
- [ ] Verification shows ✅ Valid
- [ ] localStorage shows identity and credentials
- [ ] Can create multiple identities
- [ ] Can request multiple credentials

---

## 🎯 What You've Just Deployed

✅ **Self-Sovereign Identity System** - Users control their own DIDs
✅ **Verifiable Credentials** - Cryptographically signed by issuer
✅ **Decentralized Storage** - Using IPFS (simulated or real)
✅ **Privacy-Preserving** - Encryption happens on client-side
✅ **Verification Without Authority** - Anyone can verify

---

## 🚀 Next Steps (Optional)

### Deploy to Cloud
- Deploy backend to Heroku, AWS, or Azure
- Deploy frontend to Vercel or Netlify
- Update API URL in frontend

### Add More Features
- Multiple issuer support
- Revocation mechanisms
- Wallet integration (MetaMask)
- Mobile app version
- Real blockchain storage

### Use Real IPFS
- Run IPFS daemon locally
- Or connect to public IPFS gateway

---

**🎉 You're now running a full Self-Sovereign Identity system!**

For questions or issues, check the main README.md for detailed documentation.
